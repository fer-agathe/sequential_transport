# Replication materials

The archive contains the replication materials to reproduce the results from our paper:
Fernandes Machado, A., Charpentier, A., Gallic, E. (2025). Sequential Conditional (Marginally Optimal) Transport on Probabilistic Graphs for Interpretable Counterfactual Fairness. AAAI Conference on Artificial Intelligence.

An extended version of the paper is available on arXiv: https://arxiv.org/abs/2408.03425

An ebook presenting the codes to replicate the results of the paper is available on GitHub:
https://github.com/fer-agathe/sequential_transport

To replicate the codes, provided you have installed R and Rstudio on your computer, and have also installed python (for multivariate optimal transport) double click on the following file to open RStudio (so that the correct working directory is set): `./scripts/sequential_transport.Rproj`. Then, you can open the scripts from RStudio.

The following structure is adopted.

```
Supplementary-materials
├ ── data
│    └── law_data.csv
├ ── functions
│    └── utils.R
│    └── graphs.R
├ ── seqtransfairness
├ ── scripts
|    └── 01_optimal_transport.R
|    └── 02_gaussian.R
|    └── 03_03_transport-grid.R
|    └── 04_algorithm-5.R
|    └── 05_wrong-causal-assumptions.R
|    └── 05_wrong-causal-assumptions-ot.py
|    └── 06_real-data-lawschool.R
|    └── 06_real-data-lawschool-ot.py
|    └── 07_real-data-adult.R
|    └── 07_real-data-adult-ot.py
|    └── 08_real-data-compas.R
|    └── 08_read-data-compas-ot.py
|    └── sequential_transport.Rproj
├ ── README.md
```


The python files (.py) are called within the R scripts. To replicate the results of the paper, the scripts in the `scripts/` folder mus be run in the order as it appears in the structure above. Note, however, that each file with the same prefix two digits can be run independently from one another.

## R Package

The `seqtransfairness` folder contains a copy of the initial version of the package. If this package happens to evolve in the future, putting it here allows to fully reproduce the results of the paper.

To load the package, the `load_all()` function from R package {devtools} can be used. This is what is done inside the scripts. The functions, placed in the `seqtransfairness/R/` folder are documented in the package. Hence, once the package is loaded with the `load_all()` function, the help pages can be accessed (e.g., by typing in the R console: `?seqtransfairness`, or `?seq_trans`).

## Replication of Figures and Tables

The following Figures from the paper are produced using R:

- Figure 4: 04_04_Algorithm-5.R
- Figure 6: 02_gaussian.R
- Figure 7: 04_Algorithm-5.R
- Figure 9: 06_real-data-lawschool.R
- Figure 10 (Appendix): 01_optimal_transport.R
- Figure 11 (Appendix): 01_optimal_transport.R
- Figure 12 (Appendix): 02_gaussian.R
- Figure 13 (Appendix): 02_gaussian.R
- Figure 16 (Appendix): 07_real-data-adult.R (left) and 08_real-data-compas.R (right)
- Figure 18 (Appendix): 05_wrong-causal-assumptions.R
- Figure 19 (Appendix): 05_wrong-causal-assumptions.R

The other figures are tikz pictures showing DAGs.

The following Tables are produced using R:

- Table 1: 06_real-data-lawschool.R
- Table 2 (Appendix): 07_real-data-adult.R (top) 08_real-data-compas.R (bottom)
- Table 3 (Appendix): 06_real-data-lawschool.R

